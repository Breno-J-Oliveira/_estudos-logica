programa {
  funcao inicio() {
    real v1, v2 , mult, soma, adicao, divi
    escreva (" insira um numero\n")
    leia (v1)
    escreva ("insira outro valor\n")
    leia (v2)
    soma= v1+v2
    mult= v1*v2
    adicao= v1-v2
    divi= v1/v2
    escreva (" o primeiro número ", v1," e o segundo número ", v2, " somados são iguais a ", soma, " ,substraidos são ", adicao, ", multiplicados ", mult, " e divididos são iguais a " , divi)
      } 
}
