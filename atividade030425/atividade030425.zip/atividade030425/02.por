programa {
  funcao inicio() {
    inteiro nota1, nota2, nota3, media
    escreva ("Insira sua nota\n")
    leia (nota1) 
    escreva ("Insira sua segunda nota\n")
    leia (nota2) 
     escreva ("Insira sua terceira nota\n")
    leia (nota3)
    media= (nota1+nota2+nota3)/3
         escreva ("sua média é ", media)
    //Desenvolva um programa que receba três notas de um aluno, calcule e exiba a média aritmética.
  }
}
