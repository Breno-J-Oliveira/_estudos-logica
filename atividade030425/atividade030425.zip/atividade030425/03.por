programa {
  funcao inicio() {
    real celsiu, fahrenheit
    escreva ("escreva a  temperatura em celsius para converter em fahrenheit\n")
    leia (celsiu)
    fahrenheit= celsiu*1.8+32
    escreva("seus celsius são ", celsiu, " portanto seus fahrenheit seram ", fahrenheit)
  }
}
//Faça um programa que receba a temperatura em graus Celsius e converta para Fahrenheit, exibindo o resultado.