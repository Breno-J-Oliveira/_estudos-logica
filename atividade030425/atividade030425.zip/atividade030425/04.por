programa {
  funcao inicio() {
    inteiro altura, base , area
    escreva (" escreva a altura do triangulo\n")
    leia (altura)   
    escreva (" escreva a base do triangulo\n")
    leia (base)
    area= (altura*base)/2
    escreva ("a area do triangulo é igual a ", area)
  }
}
//Crie um programa que receba a base e a altura de um retângulo, calcule e exiba a área.