programa {
  funcao inicio() {
    inteiro num1, num2, num3
    escreva ("insira seu número\n")
    leia (num1)
    num2= num1-1
    num3= num1 +1
    escreva ("O seu numero é ", num1, " e seu antecessor é ", num2, " e o sucessor é ", num3)
  }
}
//Elabore um programa que receba um número, e informe seu antecessor e seu sucessor.