programa {
  funcao inicio() {
        inteiro num1, num2, num3
    escreva ("insira seu número\n")
    leia (num1)
    num2= num1/2
    num3= num1 *2
    escreva ("O seu numero é ", num1, " e a metade dele é ", num2, " e o dobro é ", num3)
  }
}
//Metade: Desenvolva um programa que receba um número, calcule e exiba o dobro e a metade desse número.