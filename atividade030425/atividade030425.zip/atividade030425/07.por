programa {
  funcao inicio() {
        inteiro num1, num2, num3
    escreva ("Insira a quantidade de horas trabalhadas\n")
    leia (num1) 
    escreva ("Insira o valor da hora\n")
    leia (num2) 
    num3= num2*num1
    escreva ("seu salário meu patrão é de ", num3)
  }
}
//Faça um programa que receba o número de horas trabalhadas e o valor da hora, calcule e exiba o salário total. 