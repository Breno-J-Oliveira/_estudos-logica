programa {
  funcao inicio() {
          real num1, num2, num3
    escreva ("Insira a quantidade de dinheiro em real\n")
    leia (num1) 
    escreva ("Insira a cotação do dolar\n")
    leia (num2) 
    num3= num1/num2
    escreva ("seu dinheiro em dolar é de ", num3)
  }
}
//Crie um programa que receba um valor em reais e a cotação do dólar, calcule e exiba o valor equivalente em dólares.