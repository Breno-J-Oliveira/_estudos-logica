programa {
  funcao inicio() {
         inteiro num1, num2, num3
    escreva ("Insira o seu salario\n")
    leia (num1) 
    escreva ("Insira o percentual de aumento dele\n")
    leia (num2) 
    num3= ((num2*num1)/100)+num1
    escreva ("seu salário novo meu patrão é de ", num3)
  }
}
//Elabore um programa que receba o salário de um funcionário e o percentual de aumento, e exiba o novo salário.