programa {
  funcao inicio() {
    real num1, num2, num3 
    cadeia distancia, tempo
    escreva ("Insira a distancia\n")
    leia (num1) 
    escreva ("é em metros ou quilometros?\n")
    leia (distancia)
    escreva ("Insira o tempo gasto\n")
    leia (num2) 
    escreva ("em horas ou minutos?\n")
    leia (tempo)
    num3= num1/num2
    escreva ("a velocidade media é de ", num3," ", distancia, " por ", tempo)
  }
}
//Calcular a velocidade média de um objeto com base na distância percorrida e no tempo gasto.